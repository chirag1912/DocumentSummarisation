package Auto_Summary;
import preprocessor.Preprocessor;
public class main {
public main() {
	// TODO Auto-generated constructor stub
	Preprocessor.preprocess();
}
	
}
