package lex_rank;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.File;
import java.text.BreakIterator;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
public class Frequency {
	Map<String,Integer> allWords = new HashMap<String, Integer>();
	
	public HashMap<String, Integer> frequency_calculation() throws Exception{
		
		Map<String,Integer> freqWords = new HashMap<String, Integer>();
		RandomAccessFile f1 = new RandomAccessFile("F:\\Project(Summarization)\\StopWordOutput.txt", "rw");
		String text1 = f1.readLine();
		while(text1!=null){
			
			freqWords=getWordCounts(text1);
			text1=f1.readLine();
		}
		
		for(Entry<String, Integer> E: freqWords.entrySet()){
			System.out.println(E.getKey()+" ==> "+E.getValue());
		}	
		
		HashMap<String,Integer> sorted  = 
			sortByFreqThenDropFreq(freqWords);
		
		return sorted;
	}
	
	public Map<String, Integer> getWordCounts(String text)
	{
		text = text.toLowerCase();
		int count = 1;
			if(allWords.containsKey(text))//do a check to see if a word already exists in the collection
			{
				allWords.put(text, allWords.get(text)+1);
			}
			else
			{
				allWords.put  (text, count++);
			}
		//}
		return allWords;
	}
	
	
			
	private HashMap<String, Integer> sortByFreqThenDropFreq(Map<String,Integer> wordFrequencies)				
	{
		Comparator<Entry<String, Integer>> valueComparator = new Comparator<Entry<String,Integer>>() { 
			@Override public int compare(Entry<String, Integer> e1, Entry<String,Integer> e2) { 
				Integer v1 = e1.getValue(); 
				Integer v2 = e2.getValue(); 
				return v1.compareTo(v2); 
				}
			};
			
			Set<Entry<String, Integer>> entries = wordFrequencies.entrySet();
		
			// Sort method needs a List, so let's first convert Set to List in Java 
			List<Entry<String, Integer>> listOfEntries = new ArrayList<Entry<String, Integer>>(entries); 
			
			// sorting HashMap by values using comparator 
			Collections.sort(listOfEntries, valueComparator); 
			Collections.reverse(listOfEntries);
			
			HashMap<String, Integer> sortedByValue = new HashMap<String, Integer>(listOfEntries.size()); 
			
			// copying entries from List to Map 
			for(Entry<String, Integer> entry : listOfEntries){ 
				sortedByValue.put(entry.getKey(), entry.getValue()); 
				} 
			
			System.out.println("HashMap after sorting entries by values "); 
			
			Set<Entry<String, Integer>> entrySetSortedByValue = sortedByValue.entrySet(); 
			
			for(Entry<String, Integer> mapping : entrySetSortedByValue){ 
				System.out.println(mapping.getKey() + " ==> " + mapping.getValue()); 
				} 
			return sortedByValue;
	}
	
	
	private void sentence_score(HashMap<String, Integer> freqWords) throws IOException{
		
		RandomAccessFile f1 = new RandomAccessFile("F:\\Project(Summarization)\\Sample.txt", "rw");
		
		Locale locale = Locale.US;
		BreakIterator wordIterator = BreakIterator.getSentenceInstance(locale); 
		
		String text = f1.readLine();
		wordIterator.setText(text);
		
		int wordstart =wordIterator.first(); 
		for(int wordend = wordIterator.next();wordend!=BreakIterator.DONE;wordstart=wordend,wordend=wordIterator.next()){
			
			String value = Normalizer.normalize(text.substring(wordstart,wordend), Normalizer.Form.NFD);
			value=value.replaceAll("[^\\p{ASCII}]", "");
			
			int sentence_score = search(value, freqWords) ;
			System.out.println(value+" ==> "+sentence_score);
			
		}
	}
	
	
	private int search(String sentence,HashMap<String, Integer> freqWords)
	{
		//search for a particular sentence containing a particular word
        //this function will return the first matching sentence that has a value word
		
		Set<Entry<String, Integer>> entrySetSortedByValue = freqWords.entrySet(); 
		int sentence_score = 0 ;
		for(Entry<String, Integer> mapping : entrySetSortedByValue){ 
			if(sentence.toLowerCase().contains(mapping.getKey())){
				sentence_score+=mapping.getValue();
			}
		} 
		return sentence_score;
	}
	
	public static void main(String[] args) throws Exception {
		
		Frequency f = new Frequency();
		HashMap<String, Integer> freqWords =  f.frequency_calculation();
		f.sentence_score(freqWords);
		
	}
	

}
