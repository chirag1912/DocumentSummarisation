

package preprocessor;
import Auto_Summary.main;
import Sentence_Scoring.*;
import Sentence_Selection.*;

import java.io.File;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.BreakIterator;
import java.text.Normalizer;
import java.util.Locale;
import java.util.Scanner;

public class Tokeniser extends Tika_Extraction {
	
	/*public Tokeniser(String path){
		super(path);
	}*/
	
//public class try_tokenise{
	
	public void tokenise() throws Exception{
		
		
		//extract(); //extract raw text apache tika
		Locale locale = Locale.US;
		BreakIterator wordIterator = BreakIterator.getWordInstance(locale); 			//it breaks the word first and last position of break(space)
		String temp = "";
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter title of document");
		String title= sc.nextLine();
		
		TitleResemblance tit = new TitleResemblance("F:\\Project(Summarization)\\Tokens.txt",title);
		tit.Title_creation();
		
		Scanner scan =  new Scanner(new File("F:\\Project(Summarization)\\Sample.txt"));
		while(scan.hasNext()){
			temp+=" "+scan.next();
			System.out.println(temp);
		}
		
		String text = "";
		wordIterator.setText(temp);
		int wordstart =wordIterator.first(); 
		for(int wordend = wordIterator.next();
		wordend!=BreakIterator.DONE;wordstart=wordend,wordend=wordIterator.next()){
			
			String value = Normalizer.normalize(temp.substring(wordstart,wordend), Normalizer.Form.NFD);	//value =single word , normalizes unicode to suitable for sorting and searching
			value =  value.replaceAll(" ","");			//replaces all string not in ASCII format to null
			text+=" "+value;
			text =  text.replaceAll("  "," ");
		}
		temp = ""+text;		//lines followed by words
		BreakIterator iterator = BreakIterator
		.getSentenceInstance(Locale.US); 			//breaking sentences using english grammer
		iterator.setText(temp);			//pointing to temp for scanning
		
		int start = iterator.first();
		int index=0;
		FileOutputStream out = new FileOutputStream(new File("F:\\Project(Summarization)\\Tokens.txt")) ;
		
		for(int end = iterator.next(); end!=BreakIterator.DONE;start=end,end=iterator.next()){
			int spaces =0 ;
			
			String finaltext = temp.substring(start,end).trim().replaceAll("		", " "); 
				
			for(int i =0 ;i<finaltext.length();i++){
				
				if(Character.isWhitespace(finaltext.charAt(i))) spaces++;
			}
		
			if((spaces+1)<3) continue;		//minimal 3 words in a line 
			
			index++;
			 out.write(finaltext.getBytes());
	         out.write("\n".getBytes());
			
		}
	
		out.flush();
		int noOfLines = index;
		double totalNoOfCuePhrases = new CuePhrase("F:\\Project(Summarization)\\Tokens.txt").totalCuePhrases();
		double totalNoOftitleResemblences = new TitleResemblance(("F:\\Project(Summarization)\\Tokens.txt"),title).resemblence();
		scan = new Scanner(new File("F:\\Project(Summarization)\\Tokens.txt"));
		index=0;
		
		while(scan.hasNext()){
			
			//this loop
			temp = scan.nextLine();
			temp =  temp.replaceAll("[^\\p{ASCII}]","");
			if(SentenceLength.noOfWords(temp)<2)	continue;
			Sentence sentence=new Sentence(++index,temp,SentenceLength.sentenceLengthScore(SentenceLength.noOfWords(temp),15.0),SentencePosition.sentencePositionScore(index,noOfLines),new CuePhrase(null).cuePhraseScore(temp,totalNoOfCuePhrases),new TitleResemblance(null,null).titlePhraseScore(temp,totalNoOftitleResemblences));
			System.out.println(sentence.toString());
			Threshold t = new Threshold();
			boolean flag =  t.applyThreshold(SentenceLength.sentenceLengthScore(SentenceLength.noOfWords(temp),15.0),SentencePosition.sentencePositionScore(index,noOfLines),new CuePhrase(null).cuePhraseScore(temp,totalNoOfCuePhrases),new TitleResemblance(null,null).titlePhraseScore(temp,totalNoOftitleResemblences));
			if(flag){ System.out.println(temp);
			
			//insertData(sentence);
		}
		}
		out.close();

}
	public static void main(String[] args) {
	
		Tokeniser t=new Tokeniser();
		try {
			t.tokenise();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}

