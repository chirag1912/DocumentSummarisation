package preprocessor;

public class Preprocessor {
	
	public static void preprocess() throws Exception{
		
		Tokeniser extractor = new Tokeniser("F:\\Project(Summarization)\\Document.docx");
		extractor.tokenise();
		
	}

}
